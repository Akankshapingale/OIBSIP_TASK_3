/**
 * 
 */
/**
 * @author pinga
 *
 */
module Javatasks {
}